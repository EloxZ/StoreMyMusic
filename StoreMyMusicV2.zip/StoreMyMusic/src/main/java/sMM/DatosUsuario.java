/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sMM;

import java.util.HashMap;

/**
 *
 * @author Eloy
 */
public class DatosUsuario {
    private HashMap<Integer,Disco> discos; // Mapa de discos <Id Disco, Disco> (Para optimizar busquedas)
    
    public void addDisco(Disco d) {
        discos.put(d.getID(),d);
    }
    
    public void replaceDiscos(HashMap<Integer,Disco> ds) {
        discos = ds;
    }

    public HashMap<Integer, Disco> getDiscos() {
        return discos;
    }
    
    
    
}
