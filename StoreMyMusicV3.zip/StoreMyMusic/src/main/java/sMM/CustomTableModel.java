/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sMM;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Eloy
 */
public class CustomTableModel extends DefaultTableModel {
    public CustomTableModel(String[] x) {
        super(null,x);
    }
    @Override
    public boolean isCellEditable(int row, int column) {
        //all cells false
        return false;
    }
}
